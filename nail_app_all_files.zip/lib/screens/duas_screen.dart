import 'package:flutter/material.dart';

class DuasScreen extends StatelessWidget {
  const DuasScreen({super.key});

  final List<String> duas = const [
    "دعاء الصباح",
    "دعاء المساء",
    "دعاء السفر",
    "دعاء النوم",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الأدعية')),
      body: ListView.builder(
        itemCount: duas.length,
        itemBuilder: (context, i) {
          return Card(
            child: ListTile(
              title: Text(duas[i]),
            ),
          );
        },
      ),
    );
  }
}

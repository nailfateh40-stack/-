import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('نايل')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: const Text("القرآن الكريم"),
              subtitle: const Text("تصفح السور واستمع للآيات"),
              leading: const Icon(Icons.menu_book),
            ),
          ),
          Card(
            child: ListTile(
              title: const Text("مواقيت الصلاة"),
              subtitle: const Text("عرض أوقات الصلوات الخمس"),
              leading: const Icon(Icons.access_time),
            ),
          ),
          Card(
            child: ListTile(
              title: const Text("عداد التسبيح"),
              subtitle: const Text("سبّح بسهولة"),
              leading: const Icon(Icons.repeat),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

class QuranScreen extends StatelessWidget {
  const QuranScreen({super.key});

  final List<String> surahList = const [
    "الفاتحة",
    "البقرة",
    "آل عمران",
    "النساء",
    "المائدة",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('القرآن الكريم')),
      body: ListView.builder(
        itemCount: surahList.length,
        itemBuilder: (context, i) {
          return Card(
            child: ListTile(
              title: Text(surahList[i]),
              trailing: const Icon(Icons.arrow_back_ios),
            ),
          );
        },
      ),
    );
  }
}

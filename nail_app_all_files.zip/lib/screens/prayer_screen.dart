import 'package:flutter/material.dart';

class PrayerScreen extends StatelessWidget {
  const PrayerScreen({super.key});

  final Map<String, String> times = const {
    "الفجر": "05:00",
    "الظهر": "12:10",
    "العصر": "15:30",
    "المغرب": "18:20",
    "العشاء": "19:40",
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مواقيت الصلاة')),
      body: ListView(
        children: times.entries.map((e) {
          return Card(
            child: ListTile(
              title: Text(e.key),
              trailing: Text(e.value),
            ),
          );
        }).toList(),
      ),
    );
  }
}

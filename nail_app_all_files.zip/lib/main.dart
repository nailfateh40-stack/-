import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'screens/home_screen.dart';
import 'screens/quran_screen.dart';
import 'screens/prayer_screen.dart';
import 'screens/tasbeeh_screen.dart';
import 'screens/duas_screen.dart';
import 'providers/settings_provider.dart';

void main() {
  runApp(const NayelApp());
}

class NayelApp extends StatelessWidget {
  const NayelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'نايل',
        theme: ThemeData(
          primarySwatch: Colors.green,
          useMaterial3: true,
        ),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const RootPage(),
      ),
    );
  }
}

class RootPage extends StatefulWidget {
  const RootPage({super.key});

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  int index = 0;

  final pages = const [
    HomeScreen(),
    QuranScreen(),
    PrayerScreen(),
    TasbeehScreen(),
    DuasScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[index],
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: index,
          onTap: (i) => setState(() => index = i),
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
            BottomNavigationBarItem(icon: Icon(Icons.book), label: 'القرآن'),
            BottomNavigationBarItem(icon: Icon(Icons.access_time), label: 'مواقيت'),
            BottomNavigationBarItem(icon: Icon(Icons.repeat), label: 'تسبيح'),
            BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'أدعية'),
          ],
        ),
      ),
    );
  }
}
